cd ../
python setup.py install
cd ./examples
