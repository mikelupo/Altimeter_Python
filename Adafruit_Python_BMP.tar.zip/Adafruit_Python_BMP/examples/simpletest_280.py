#!/usr/bin/python
# Author: Bastien Wirtz <bastien.wirtz@gmail.com>

# Can enable debug output by uncommenting:
import logging
logging.basicConfig(level=logging.CRITICAL)

#import argparse  #we can use this later when I really want to have robust argumentation.
import Adafruit_BMP.BMP280 as BMP280
import sys
from Tkinter import *

sensor = BMP280.BMP280()
CONVERSION_CONST = 3386.38816

sealevel_inHg = float(sys.argv[1])
sealevel_pa = CONVERSION_CONST * sealevel_inHg

print "#########################################################"
print 'This is the pressure you input', str(sealevel_inHg)
print 'This is the calculated pressure in pa', str(sealevel_pa)
print "##########################################################"

print 'Temp = {0:0.2f} *C'.format(sensor.read_temperature())
print 'Pressure = {0:0.2f} Pa'.format(sensor.read_pressure())
print 'Altitude = {0:0.2f} ft'.format(sensor.read_altitude_feet(sealevel_pa))
print 'Sealevel Pressure = {0:0.2f} Pa'.format(sensor.read_sealevel_pressure())

#root = Tk()

#w = Label(root, text="Hello, world!")
#w.pack()

#root.mainloop()
